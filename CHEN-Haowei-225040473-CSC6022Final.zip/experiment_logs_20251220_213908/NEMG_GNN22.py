# -*- coding: utf-8 -*-
"""
Created on Sat Dec 20 21:39:06 2025

@author: 17100
"""

import numpy as np
import networkx as nx
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import GCNConv
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
from collections import deque
import random
import sys
import os
from datetime import datetime

# ============================================================================
# LOGGER CLASS
# ============================================================================

class TeeLogger:
    def __init__(self, log_dir, prefix="log"):
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
       
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        log_filename = os.path.join(log_dir, f"{prefix}_{timestamp}.txt")
       
        self.terminal = sys.stdout
        self.log_file = open(log_filename, 'w', encoding='utf-8')
        self.log_filename = log_filename
        self.log_dir = log_dir
       
        self.log_file.write(f"Log started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        self.log_file.write("="*80 + "\n\n")
        self.log_file.flush()
   
    def write(self, message):
        try:
            self.terminal.write(message)
        except UnicodeEncodeError:
            self.terminal.write(message.encode('ascii', 'replace').decode('ascii'))
       
        self.log_file.write(message)
        self.log_file.flush()
   
    def flush(self):
        self.terminal.flush()
        self.log_file.flush()
   
    def close(self):
        self.log_file.write("\n" + "="*80 + "\n")
        self.log_file.write(f"Log ended at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        self.log_file.close()
        sys.stdout = self.terminal
        print(f"\nLog saved to: {self.log_filename}")

# ============================================================================
# NETWORK GENERATION FUNCTIONS
# ============================================================================

def generate_star_graph(num_nodes):
    """
    Generate a star graph with one central hub connected to all other nodes.
   
    Args:
        num_nodes: Total number of nodes (including hub)
   
    Returns:
        NetworkX graph object
    """
    if num_nodes < 2:
        raise ValueError("Star graph needs at least 2 nodes")
   
    G = nx.star_graph(num_nodes - 1)  # nx.star_graph(n) creates n+1 nodes
    print(f"Star graph: 1 hub node, {num_nodes-1} leaf nodes")
    print(f"Hub degree: {num_nodes-1}, Leaf degree: 1")
    return G


def generate_small_world_graph(num_nodes, k=4, p=0.3):
    """
    Generate a Watts-Strogatz small-world graph.
   
    Args:
        num_nodes: Number of nodes
        k: Each node is connected to k nearest neighbors in ring topology (must be even)
        p: Probability of rewiring each edge
   
    Returns:
        NetworkX graph object
    """
    if k >= num_nodes:
        k = num_nodes - 1
    if k % 2 != 0:
        k += 1  # k must be even
   
    G = nx.watts_strogatz_graph(num_nodes, k, p)
   
    # Ensure connectivity
    if not nx.is_connected(G):
        components = list(nx.connected_components(G))
        for i in range(len(components) - 1):
            node1 = list(components[i])[0]
            node2 = list(components[i + 1])[0]
            G.add_edge(node1, node2)
   
    print(f"Small-world graph: n={num_nodes}, k={k}, p={p}")
    print(f"Clustering coefficient: {nx.average_clustering(G):.3f}")
    print(f"Average shortest path: {nx.average_shortest_path_length(G):.3f}")
    return G


def generate_regular_graph(num_nodes, degree=4):
    """
    Generate a random regular graph where all nodes have the same degree.
   
    Args:
        num_nodes: Number of nodes
        degree: Degree of each node (must result in even number of total edges)
   
    Returns:
        NetworkX graph object
    """
    # For regular graph: num_nodes * degree must be even
    if (num_nodes * degree) % 2 != 0:
        degree += 1
   
    if degree >= num_nodes:
        degree = num_nodes - 1
   
    # Ensure valid configuration
    if (num_nodes * degree) % 2 != 0:
        degree -= 1
   
    try:
        G = nx.random_regular_graph(degree, num_nodes)
    except nx.NetworkXError:
        # If random regular graph fails, use cycle and add edges
        G = nx.cycle_graph(num_nodes)
        current_degree = 2
       
        # Add edges to reach desired degree
        while current_degree < degree:
            for node in range(num_nodes):
                if G.degree(node) < degree:
                    for other in range(node + 1, num_nodes):
                        if G.degree(other) < degree and not G.has_edge(node, other):
                            G.add_edge(node, other)
                            if G.degree(node) >= degree:
                                break
            current_degree = min([G.degree(n) for n in G.nodes()])
   
    print(f"Regular graph: n={num_nodes}, degree={degree}")
    print(f"All nodes have degree: {degree}")
    return G


def generate_bipartite_graph(num_nodes, p=0.3):
    """
    Generate a random bipartite graph with two partitions.
   
    Args:
        num_nodes: Total number of nodes
        p: Probability of edge between nodes in different partitions
   
    Returns:
        NetworkX graph object
    """
    n1 = num_nodes // 2
    n2 = num_nodes - n1
   
    G = nx.bipartite.random_graph(n1, n2, p)
   
    # Ensure connectivity
    if not nx.is_connected(G):
        components = list(nx.connected_components(G))
        for i in range(len(components) - 1):
            comp1_nodes = list(components[i])
            comp2_nodes = list(components[i + 1])
           
            top_nodes = {n for n, d in G.nodes(data=True) if d.get('bipartite') == 0}
           
            node1 = comp1_nodes[0]
            for node2 in comp2_nodes:
                if (node1 in top_nodes) != (node2 in top_nodes):
                    G.add_edge(node1, node2)
                    break
            else:
                G.add_edge(comp1_nodes[0], comp2_nodes[0])
   
    is_bipartite = nx.is_bipartite(G)
   
    print(f"Bipartite graph: n={num_nodes} ({n1} + {n2}), p={p}")
    print(f"Is bipartite: {is_bipartite}")
    print(f"Number of edges: {G.number_of_edges()}")
   
    return G


def generate_erdos_renyi_graph(num_nodes, p=0.02):
    """
    Generate an Erdos-Renyi random graph.
   
    Args:
        num_nodes: Number of nodes
        p: Probability of edge creation between any pair of nodes
   
    Returns:
        NetworkX graph object
    """
    G = nx.erdos_renyi_graph(num_nodes, p)
   
    # Ensure connectivity
    if not nx.is_connected(G):
        components = list(nx.connected_components(G))
        for i in range(len(components) - 1):
            node1 = list(components[i])[0]
            node2 = list(components[i + 1])[0]
            G.add_edge(node1, node2)
   
    print(f"Erdos-Renyi graph: n={num_nodes}, p={p}")
    print(f"Clustering coefficient: {nx.average_clustering(G):.3f}")
    print(f"Average shortest path: {nx.average_shortest_path_length(G):.3f}")
    return G


def create_network(num_nodes, graph_type='small_world', **kwargs):
    """
    Create a network based on specified graph type.
   
    Args:
        num_nodes: Number of nodes
        graph_type: One of ['star', 'small_world', 'regular', 'bipartite', 'erdos_renyi']
        **kwargs: Additional parameters for specific graph types
   
    Returns:
        NetworkX graph object
    """
    graph_type = graph_type.lower()
   
    if graph_type == 'star':
        return generate_star_graph(num_nodes)
    elif graph_type == 'small_world':
        k = kwargs.get('k', 4)
        p = kwargs.get('p', 0.3)
        return generate_small_world_graph(num_nodes, k, p)
    elif graph_type == 'regular':
        degree = kwargs.get('degree', 4)
        return generate_regular_graph(num_nodes, degree)
    elif graph_type == 'bipartite':
        p = kwargs.get('p', 0.3)
        return generate_bipartite_graph(num_nodes, p)
    elif graph_type == 'erdos_renyi':
        p = kwargs.get('p', 0.02)
        return generate_erdos_renyi_graph(num_nodes, p)
    else:
        raise ValueError(f"Unknown graph type: {graph_type}")


def visualize_network(G, graph_type, save_path=None):
    """
    Visualize the network structure.
   
    Args:
        G: NetworkX graph
        graph_type: Type of graph for title
        save_path: Optional path to save figure
    """
    fig, ax = plt.subplots(figsize=(12, 8))
   
    # Choose layout based on graph type
    if graph_type == 'star':
        pos = nx.spring_layout(G, k=2, iterations=50)
    elif graph_type == 'bipartite':
        try:
            top_nodes = {n for n, d in G.nodes(data=True) if d.get('bipartite') == 0}
            pos = nx.bipartite_layout(G, top_nodes)
        except:
            pos = nx.spring_layout(G)
    else:
        pos = nx.spring_layout(G, k=1, iterations=50)
   
    # Draw network
    nx.draw(G, pos,
            node_color='lightblue',
            node_size=500,
            with_labels=True,
            font_size=8,
            font_weight='bold',
            edge_color='gray',
            width=1.5,
            alpha=0.7,
            ax=ax)
   
    # Add title with network statistics
    degree_sequence = [d for n, d in G.degree()]
    avg_degree = np.mean(degree_sequence)
   
    ax.set_title(f'{graph_type.title()} Graph\n'
                 f'Nodes: {G.number_of_nodes()}, Edges: {G.number_of_edges()}, '
                 f'Avg Degree: {avg_degree:.2f}',
                 fontsize=14, fontweight='bold')
   
    plt.tight_layout()
   
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Network visualization saved to {save_path}")
   
    plt.close(fig)


# ============================================================================
# AGENT AND GAME LOGIC
# ============================================================================

class Agent:
    def __init__(self, memory_size=5, strategy=None):
        self.memory_size = memory_size
        self.memory = deque(maxlen=memory_size)
       
        # Initialize random strategy if not provided
        if strategy is None:
            num_strategies = 2 ** memory_size
            self.strategy = np.random.choice([0, 1], size=num_strategies)
        else:
            self.strategy = strategy.copy()
       
        self.current_action = np.random.choice([0, 1])
        self.score = 0
        self.action_history = []
   
    def get_action(self):
        """Get action based on current memory and strategy."""
        if len(self.memory) < self.memory_size:
            # Random action if memory not full
            self.current_action = np.random.choice([0, 1])
        else:
            # Convert memory to index
            memory_state = sum([bit * (2 ** i) for i, bit in enumerate(self.memory)])
            self.current_action = self.strategy[memory_state]
       
        return self.current_action
   
    def update(self, reward, minority_action):
        """Update agent's score and memory."""
        self.score += reward
        self.memory.append(minority_action)
        self.action_history.append(self.current_action)
   
    def reset_score(self):
        """Reset score for new evaluation period."""
        self.score = 0


class NetworkMinorityGame:
    def __init__(self, num_nodes, graph_type='small_world', memory_size=5, **graph_kwargs):
        """
        Initialize the Network Minority Game.
       
        Args:
            num_nodes: Number of agents/nodes
            graph_type: Type of network
            memory_size: Memory length for agents
            **graph_kwargs: Additional parameters for network generation
        """
        self.num_nodes = num_nodes
        self.memory_size = memory_size
        self.graph_type = graph_type
       
        # Create network
        print(f"\n{'='*60}")
        print(f"Creating {graph_type.upper()} network with {num_nodes} nodes")
        print(f"{'='*60}")
        self.network = create_network(num_nodes, graph_type, **graph_kwargs)
       
        # Initialize agents
        self.agents = [Agent(memory_size) for _ in range(num_nodes)]
       
        # History tracking
        self.global_minority_history = []
        self.payoff_history = []  # Will store list of lists: [[r0_a0, r0_a1, ...], [r1_a0, ...], ...]
        self.attendance_history = []
       
        # Network statistics
        self.print_network_stats()
   
    def print_network_stats(self):
        """Print detailed network statistics."""
        print(f"\n{'='*60}")
        print("NETWORK STATISTICS")
        print(f"{'='*60}")
        print(f"Number of nodes: {self.network.number_of_nodes()}")
        print(f"Number of edges: {self.network.number_of_edges()}")
       
        degrees = [d for n, d in self.network.degree()]
        print(f"Average degree: {np.mean(degrees):.2f}")
        print(f"Min degree: {np.min(degrees)}")
        print(f"Max degree: {np.max(degrees)}")
        print(f"Degree std: {np.std(degrees):.2f}")
       
        print(f"Is connected: {nx.is_connected(self.network)}")
        print(f"Average clustering: {nx.average_clustering(self.network):.3f}")
       
        if nx.is_connected(self.network):
            print(f"Average shortest path: {nx.average_shortest_path_length(self.network):.3f}")
            print(f"Diameter: {nx.diameter(self.network)}")
       
        print(f"{'='*60}\n")
   
    def play_round(self):
        """
        Play one round of the minority game.
        
        - All agents observe the same global minority history
        - Win/lose determined by GLOBAL minority
        - Network affects strategy evolution through local imitation
        """
        # Get actions from all agents
        actions = [agent.get_action() for agent in self.agents]
       
        # Track attendance (number choosing 1)
        attendance = sum(actions)
        self.attendance_history.append(attendance)
       

        global_count_ones = sum(actions)
        global_count_zeros = self.num_nodes - global_count_ones
       
        # Determine global minority (tie-breaking: if equal, minority is 1)
        if global_count_zeros < global_count_ones:
            global_minority = 0
        elif global_count_ones < global_count_zeros:
            global_minority = 1
        else:  # Tie
            global_minority = 1
       

        round_payoffs = []
       

        for node_idx in range(self.num_nodes):
            # Reward if agent chose global minority
            reward = 1 if actions[node_idx] == global_minority else 0
           
            # Update agent (all agents see same global minority)
            self.agents[node_idx].update(reward, global_minority)
           

            round_payoffs.append(reward)
       
        # Track global minority history
        self.global_minority_history.append(global_minority)
       

        self.payoff_history.append(round_payoffs)
   
    def evolve_strategies(self, selection_pressure=1.0, mutation_rate=0.01):
        """
        Evolve strategies using local imitation dynamics.
       
        Args:
            selection_pressure: Beta parameter for Fermi rule
            mutation_rate: Probability of random strategy mutation
        """
        new_strategies = []
       
        for node_idx in range(self.num_nodes):
            neighbors = list(self.network.neighbors(node_idx))
           
            if len(neighbors) == 0:
                # Isolated node keeps its strategy
                new_strategies.append(self.agents[node_idx].strategy.copy())
                continue
           
            # Current agent's fitness
            my_fitness = self.agents[node_idx].score
           
            # Select a random neighbor
            neighbor_idx = np.random.choice(neighbors)
            neighbor_fitness = self.agents[neighbor_idx].score
           
            # Imitation probability (Fermi rule)
            fitness_diff = neighbor_fitness - my_fitness
            imitation_prob = 1 / (1 + np.exp(-selection_pressure * fitness_diff))
           
            # Decide whether to imitate
            if np.random.random() < imitation_prob:
                # Imitate neighbor's strategy
                new_strategy = self.agents[neighbor_idx].strategy.copy()
            else:
                # Keep own strategy
                new_strategy = self.agents[node_idx].strategy.copy()
           
            # Mutation
            if np.random.random() < mutation_rate:
                # Flip random bits in strategy
                num_flips = np.random.randint(1, len(new_strategy) // 4 + 1)
                flip_positions = np.random.choice(len(new_strategy), num_flips, replace=False)
                for pos in flip_positions:
                    new_strategy[pos] = 1 - new_strategy[pos]
           
            new_strategies.append(new_strategy)
       
        # Update all strategies
        for agent, new_strategy in zip(self.agents, new_strategies):
            agent.strategy = new_strategy
            agent.reset_score()
   
    def run_simulation(self, num_rounds=10000, evolution_interval=100):
        """
        Run the full simulation.
       
        Args:
            num_rounds: Total number of rounds
            evolution_interval: Evolve strategies every N rounds
        """
        print(f"\nRunning simulation for {num_rounds} rounds...")
        print(f"Evolution every {evolution_interval} rounds\n")
       
        for round_num in range(num_rounds):
            self.play_round()
           
            # Evolve strategies periodically
            if (round_num + 1) % evolution_interval == 0:
                self.evolve_strategies()
               
                if (round_num + 1) % 1000 == 0:
                    avg_payoff = np.mean([agent.score for agent in self.agents])
                    print(f"Round {round_num + 1}: Average payoff = {avg_payoff:.4f}")
       
        print("\nSimulation completed!")
   
    def get_training_data(self, history_length=20):
        """
        Prepare training data for GCN.
       
        Args:
            history_length: Length of action history to use as features
       
        Returns:
            action_histories: Array of shape (num_nodes, history_length)
            strategies: Array of shape (num_nodes, 2^memory_size)
            edge_index: Edge list for PyTorch Geometric
        """
        # Get action histories
        action_histories = []
        for agent in self.agents:
            history = agent.action_history[-history_length:]
            # Pad if necessary
            if len(history) < history_length:
                history = [0] * (history_length - len(history)) + history
            action_histories.append(history)
       
        action_histories = np.array(action_histories, dtype=np.float32)
       
        # Get strategies
        strategies = np.array([agent.strategy for agent in self.agents], dtype=np.float32)
       
        # Get edge index
        edge_list = list(self.network.edges())
        edge_index = []
        for edge in edge_list:
            edge_index.append([edge[0], edge[1]])
            edge_index.append([edge[1], edge[0]])  # Undirected graph
       
        edge_index = np.array(edge_index, dtype=np.int64).T
       
        return action_histories, strategies, edge_index
   
    def compute_variance_metrics(self):
        """
        Compute variance of attendance/N and compare with 2^m/N.
       
        Returns:
            variance_A_over_N: Variance of attendance/N
            theoretical_ratio: 2^m/N
        """
        # Compute normalized attendance
        attendance_normalized = np.array(self.attendance_history) / self.num_nodes
       
        # Compute variance
        variance_A_over_N = np.var(attendance_normalized)
       
        # Compute theoretical ratio
        theoretical_ratio = (2 ** self.memory_size) / self.num_nodes
       
        return variance_A_over_N, theoretical_ratio


# ============================================================================
# GCN MODELS
# ============================================================================

class FullNetworkGCN(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(FullNetworkGCN, self).__init__()
        self.conv1 = GCNConv(input_dim, hidden_dim)
        self.conv2 = GCNConv(hidden_dim, hidden_dim)
        self.conv3 = GCNConv(hidden_dim, hidden_dim)
        self.fc = nn.Linear(hidden_dim, output_dim)
   
    def forward(self, data):
        x, edge_index = data.x, data.edge_index
       
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = F.dropout(x, p=0.2, training=self.training)
       
        x = self.conv2(x, edge_index)
        x = F.relu(x)
        x = F.dropout(x, p=0.2, training=self.training)
       
        x = self.conv3(x, edge_index)
        x = F.relu(x)
       
        x = self.fc(x)
        return torch.sigmoid(x)


class EgoNetworkGCN(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(EgoNetworkGCN, self).__init__()
        self.conv1 = GCNConv(input_dim, hidden_dim)
        self.conv2 = GCNConv(hidden_dim, hidden_dim)
        self.fc = nn.Linear(hidden_dim, output_dim)
   
    def forward(self, data):
        x, edge_index = data.x, data.edge_index
       
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = F.dropout(x, p=0.2, training=self.training)
       
        x = self.conv2(x, edge_index)
        x = F.relu(x)
       
        x = self.fc(x)
        return torch.sigmoid(x)


# ============================================================================
# TRAINING AND EVALUATION
# ============================================================================

def train_full_network_gcn(game, num_epochs=200, learning_rate=0.001):
    """Train GCN on full network."""
    print("\n" + "="*60)
    print("TRAINING FULL NETWORK GCN")
    print("="*60)
   
    # Prepare data
    action_histories, strategies, edge_index = game.get_training_data()
   
    input_dim = action_histories.shape[1]
    output_dim = strategies.shape[1]
    hidden_dim = 64
   
    # Create PyTorch Geometric data
    data = Data(
        x=torch.FloatTensor(action_histories),
        edge_index=torch.LongTensor(edge_index),
        y=torch.FloatTensor(strategies)
    )
   
    # Initialize model
    model = FullNetworkGCN(input_dim, hidden_dim, output_dim)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    criterion = nn.BCELoss()
   
    # Training loop
    model.train()
    for epoch in range(num_epochs):
        optimizer.zero_grad()
        out = model(data)
        loss = criterion(out, data.y)
        loss.backward()
        optimizer.step()
       
        if (epoch + 1) % 50 == 0:
            print(f"Epoch {epoch+1}/{num_epochs}, Loss: {loss.item():.4f}")
   
    print("Training completed!")
    return model


def train_ego_network_gcn(game, num_epochs=200, learning_rate=0.001):
    """Train GCN on ego networks."""
    print("\n" + "="*60)
    print("TRAINING EGO NETWORK GCN")
    print("="*60)
   
    action_histories, strategies, _ = game.get_training_data()
   
    input_dim = action_histories.shape[1]
    output_dim = strategies.shape[1]
    hidden_dim = 64
   
    model = EgoNetworkGCN(input_dim, hidden_dim, output_dim)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    criterion = nn.BCELoss()
   
    # Training loop
    for epoch in range(num_epochs):
        total_loss = 0
       
        # Train on each ego network
        for target_node in range(game.num_nodes):
            # Get ego network
            neighbors = list(game.network.neighbors(target_node))
            ego_nodes = [target_node] + neighbors
           
            # Extract subgraph
            ego_subgraph = game.network.subgraph(ego_nodes)
           
            # Prepare ego network data
            ego_action_histories = action_histories[ego_nodes]
            ego_strategies = strategies[target_node:target_node+1]  # Only target
           
            # Create edge index for ego network
            node_mapping = {node: idx for idx, node in enumerate(ego_nodes)}
            ego_edges = []
            for edge in ego_subgraph.edges():
                ego_edges.append([node_mapping[edge[0]], node_mapping[edge[1]]])
                ego_edges.append([node_mapping[edge[1]], node_mapping[edge[0]]])
           
            if len(ego_edges) == 0:
                continue
           
            ego_edge_index = torch.LongTensor(ego_edges).T
           
            # Create data
            data = Data(
                x=torch.FloatTensor(ego_action_histories),
                edge_index=ego_edge_index,
                y=torch.FloatTensor(ego_strategies)
            )
           
            # Forward pass
            model.train()
            optimizer.zero_grad()
            out = model(data)
           
            # Loss only on target node (index 0 in ego network)
            loss = criterion(out[0:1], data.y)
            loss.backward()
            optimizer.step()
           
            total_loss += loss.item()
       
        avg_loss = total_loss / game.num_nodes
       
        if (epoch + 1) % 50 == 0:
            print(f"Epoch {epoch+1}/{num_epochs}, Avg Loss: {avg_loss:.4f}")
   
    print("Training completed!")
    return model


def evaluate_model(model, game, model_type='full'):
    """Evaluate trained model by running simulation with predicted strategies."""
    print(f"\n{'='*60}")
    print(f"EVALUATING {model_type.upper()} NETWORK GCN")
    print(f"{'='*60}")
   
    # Get predictions
    action_histories, _, edge_index = game.get_training_data()
   
    model.eval()
    with torch.no_grad():
        if model_type == 'full':
            data = Data(
                x=torch.FloatTensor(action_histories),
                edge_index=torch.LongTensor(edge_index)
            )
            predictions = model(data).numpy()
        else:  # ego
            predictions = []
            for target_node in range(game.num_nodes):
                neighbors = list(game.network.neighbors(target_node))
                ego_nodes = [target_node] + neighbors
                ego_subgraph = game.network.subgraph(ego_nodes)
               
                ego_action_histories = action_histories[ego_nodes]
               
                node_mapping = {node: idx for idx, node in enumerate(ego_nodes)}
                ego_edges = []
                for edge in ego_subgraph.edges():
                    ego_edges.append([node_mapping[edge[0]], node_mapping[edge[1]]])
                    ego_edges.append([node_mapping[edge[1]], node_mapping[edge[0]]])
               
                if len(ego_edges) == 0:
                    predictions.append(np.random.choice([0, 1], size=2**game.memory_size))
                    continue
               
                ego_edge_index = torch.LongTensor(ego_edges).T
               
                data = Data(
                    x=torch.FloatTensor(ego_action_histories),
                    edge_index=ego_edge_index
                )
               
                pred = model(data)[0].numpy()
                predictions.append(pred)
           
            predictions = np.array(predictions)
   
    # Convert predictions to binary strategies
    predicted_strategies = (predictions > 0.5).astype(int)
   
    # Create new game with predicted strategies
    eval_game = NetworkMinorityGame(
        game.num_nodes,
        game.graph_type,
        game.memory_size
    )
   
    # Copy network structure from original game
    eval_game.network = game.network.copy()
   
    # Set predicted strategies
    for i, agent in enumerate(eval_game.agents):
        agent.strategy = predicted_strategies[i]
   
    # Run evaluation
    eval_game.run_simulation(num_rounds=20000, evolution_interval=100000)  # No evolution
   
    avg_payoff = np.mean([agent.score for agent in eval_game.agents])
    print(f"\nAverage payoff with {model_type} GCN strategies: {avg_payoff:.4f}")
   
    return avg_payoff, eval_game


def plot_results(game, full_eval_game, ego_eval_game, graph_type, save_dir):
    """
    Plot attendance and payoff histories.
    """
   
    # Helper function for downsampling
    def downsample(data, window=50):
        """Downsample data by averaging over windows."""
        n = len(data)
        downsampled = []
        x_vals = []
        for i in range(0, n, window):
            chunk = data[i:i+window]
            if len(chunk) > 0:
                downsampled.append(np.mean(chunk))
                x_vals.append(i + window//2)
        return x_vals, downsampled
   
    # =================================================================
    # FIGURE 1: ATTENDANCE
    # =================================================================
    fig1, axes1 = plt.subplots(1, 3, figsize=(20, 5))
   
    window = 50
   
    # Subplot 1: Evolved strategies
    ax1 = axes1[0]
    x_evolved, y_evolved = downsample(game.attendance_history, window)
    ax1.plot(x_evolved, y_evolved, color='blue', alpha=0.8, linewidth=1.5)
    ax1.axhline(y=game.num_nodes/2, color='red', linestyle='--', label='N/2', linewidth=2, alpha=0.7)
    ax1.set_xlabel('Round', fontsize=12)
    ax1.set_ylabel('Attendance (# choosing 1)', fontsize=12)
    ax1.set_title('Evolved Strategies', fontsize=14, fontweight='bold')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
   
    # Subplot 2: Full GCN strategies
    ax2 = axes1[1]
    x_full, y_full = downsample(full_eval_game.attendance_history, window)
    ax2.plot(x_full, y_full, color='green', alpha=0.8, linewidth=1.5)
    ax2.axhline(y=game.num_nodes/2, color='red', linestyle='--', label='N/2', linewidth=2, alpha=0.7)
    ax2.set_xlabel('Round', fontsize=12)
    ax2.set_ylabel('Attendance (# choosing 1)', fontsize=12)
    ax2.set_title('Full GCN Strategies', fontsize=14, fontweight='bold')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
   
    # Subplot 3: Ego GCN strategies
    ax3 = axes1[2]
    x_ego, y_ego = downsample(ego_eval_game.attendance_history, window)
    ax3.plot(x_ego, y_ego, color='orange', alpha=0.8, linewidth=1.5)
    ax3.axhline(y=game.num_nodes/2, color='red', linestyle='--', label='N/2', linewidth=2, alpha=0.7)
    ax3.set_xlabel('Round', fontsize=12)
    ax3.set_ylabel('Attendance (# choosing 1)', fontsize=12)
    ax3.set_title('Ego GCN Strategies', fontsize=14, fontweight='bold')
    ax3.legend()
    ax3.grid(True, alpha=0.3)
   
    fig1.suptitle(f'Attendance vs Rounds - {graph_type.title()} Graph\n(Averaged over {window} rounds)',
                  fontsize=16, fontweight='bold', y=1.02)
    plt.tight_layout()
   
    save_path1 = os.path.join(save_dir, f'{graph_type}_attendance.png')
    plt.savefig(save_path1, dpi=300, bbox_inches='tight')
    print(f"Attendance plot saved to {save_path1}")
    plt.close(fig1)
   
    fig2, axes2 = plt.subplots(1, 3, figsize=(20, 5))
   

    evolved_payoffs = np.array(game.payoff_history)  # Shape: (num_rounds, num_agents)
    full_payoffs = np.array(full_eval_game.payoff_history)
    ego_payoffs = np.array(ego_eval_game.payoff_history)
   
    print(f"\n Payoff array shapes:")
    print(f"  Evolved: {evolved_payoffs.shape}")
    print(f"  Full GCN: {full_payoffs.shape}")
    print(f"  Ego GCN: {ego_payoffs.shape}")
   
    evolved_cumavg = np.cumsum(evolved_payoffs, axis=0) / np.arange(1, len(evolved_payoffs) + 1)[:, np.newaxis]
    full_cumavg = np.cumsum(full_payoffs, axis=0) / np.arange(1, len(full_payoffs) + 1)[:, np.newaxis]
    ego_cumavg = np.cumsum(ego_payoffs, axis=0) / np.arange(1, len(ego_payoffs) + 1)[:, np.newaxis]
   

    evolved_avg = np.mean(evolved_cumavg, axis=1)
    full_avg = np.mean(full_cumavg, axis=1)
    ego_avg = np.mean(ego_cumavg, axis=1)
   
    print(f"Average payoff shapes:")
    print(f"  Evolved: {evolved_avg.shape}")
    print(f"  Full GCN: {full_avg.shape}")
    print(f"  Ego GCN: {ego_avg.shape}")
   
    # Downsample for faster plotting
    x_e, y_e = downsample(evolved_avg, window)
    x_f, y_f = downsample(full_avg, window)
    x_eg, y_eg = downsample(ego_avg, window)
   
    # Subplot 1: Evolved strategies
    ax1 = axes2[0]
    ax1.plot(x_e, y_e, color='blue', alpha=0.8, linewidth=2)
    ax1.axhline(y=0.5, color='red', linestyle='--', label='Max (0.5)', linewidth=2, alpha=0.7)
    ax1.set_xlabel('Round', fontsize=12)
    ax1.set_ylabel('Cumulative Average Payoff', fontsize=12)
    ax1.set_title('Evolved Strategies', fontsize=14, fontweight='bold')
    ax1.set_ylim([0, 0.6])
    ax1.legend()
    ax1.grid(True, alpha=0.3)
   
    # Subplot 2: Full GCN strategies
    ax2 = axes2[1]
    ax2.plot(x_f, y_f, color='green', alpha=0.8, linewidth=2)
    ax2.axhline(y=0.5, color='red', linestyle='--', label='Max (0.5)', linewidth=2, alpha=0.7)
    ax2.set_xlabel('Round', fontsize=12)
    ax2.set_ylabel('Cumulative Average Payoff', fontsize=12)
    ax2.set_title('Full GCN Strategies', fontsize=14, fontweight='bold')
    ax2.set_ylim([0, 0.6])
    ax2.legend()
    ax2.grid(True, alpha=0.3)
   
    # Subplot 3: Ego GCN strategies
    ax3 = axes2[2]
    ax3.plot(x_eg, y_eg, color='orange', alpha=0.8, linewidth=2)
    ax3.axhline(y=0.5, color='red', linestyle='--', label='Max (0.5)', linewidth=2, alpha=0.7)
    ax3.set_xlabel('Round', fontsize=12)
    ax3.set_ylabel('Cumulative Average Payoff', fontsize=12)
    ax3.set_title('Ego GCN Strategies', fontsize=14, fontweight='bold')
    ax3.set_ylim([0, 0.6])
    ax3.legend()
    ax3.grid(True, alpha=0.3)
   
    fig2.suptitle(f'Cumulative Average Payoff vs Rounds - {graph_type.title()} Graph',
                  fontsize=16, fontweight='bold', y=1.02)
    plt.tight_layout()
   
    save_path2 = os.path.join(save_dir, f'{graph_type}_payoff.png')
    plt.savefig(save_path2, dpi=300, bbox_inches='tight')
    print(f"Payoff plot saved to {save_path2}")
    plt.close(fig2)
   
    # =================================================================
    # PRINT VARIANCE STATISTICS
    # =================================================================
    var_evolved, theoretical = game.compute_variance_metrics()
    var_full, _ = full_eval_game.compute_variance_metrics()
    var_ego, _ = ego_eval_game.compute_variance_metrics()
   
    print(f"\n{'='*60}")
    print(f"VARIANCE ANALYSIS - {graph_type.upper()}")
    print(f"{'='*60}")
    print(f"Memory size (m): {game.memory_size}")
    print(f"Number of agents (N): {game.num_nodes}")
    print(f"Theoretical ratio (2^m/N): {theoretical:.6f}")
    print(f"\nVariance of A/N:")
    print(f"  Evolved strategies:  {var_evolved:.6f}")
    print(f"  Full GCN strategies: {var_full:.6f}")
    print(f"  Ego GCN strategies:  {var_ego:.6f}")
    print(f"\nRatio to theoretical:")
    print(f"  Evolved:  {var_evolved/theoretical:.4f}")
    print(f"  Full GCN: {var_full/theoretical:.4f}")
    print(f"  Ego GCN:  {var_ego/theoretical:.4f}")
    print(f"{'='*60}\n")


# ============================================================================
# MAIN EXPERIMENT
# ============================================================================

def run_experiment(num_nodes=301, graph_type='small_world', save_dir=None, **graph_kwargs):
    """
    Run complete experiment with specified graph type.
    """
    print("\n" + "="*80)
    print(f"NETWORK MINORITY GAME EXPERIMENT - {graph_type.upper()} GRAPH")
    print("="*80)
   
    # Initialize and run game
    game = NetworkMinorityGame(
        num_nodes=num_nodes,
        graph_type=graph_type,
        memory_size=4,
        **graph_kwargs
    )
   
    # Visualize network
    if save_dir:
        visualize_network(game.network, graph_type,
                         save_path=os.path.join(save_dir, f'{graph_type}_network.png'))
   
    # Run simulation
    game.run_simulation(num_rounds=10000, evolution_interval=100)
   
    # Train models
    full_model = train_full_network_gcn(game, num_epochs=200)
    ego_model = train_ego_network_gcn(game, num_epochs=200)
   
    # Evaluate models
    full_payoff, full_eval_game = evaluate_model(full_model, game, 'full')
    ego_payoff, ego_eval_game = evaluate_model(ego_model, game, 'ego')
   
    # Plot results
    if save_dir:
        plot_results(game, full_eval_game, ego_eval_game, graph_type, save_dir)
   
    # Compare results
    print("\n" + "="*80)
    print("FINAL RESULTS")
    print("="*80)
    print(f"Graph Type: {graph_type.upper()}")
    print(f"Number of nodes: {num_nodes}")
    print(f"Number of edges: {game.network.number_of_edges()}")
    print(f"Average degree: {np.mean([d for n, d in game.network.degree()]):.2f}")
    print(f"\nFull Network GCN Payoff: {full_payoff:.4f}")
    print(f"Ego Network GCN Payoff: {ego_payoff:.4f}")
    print(f"Relative Performance: {(ego_payoff/full_payoff)*100:.2f}%")
    print("="*80)
   
    return game, full_model, ego_model


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    # Create log directory and logger
    log_dir = f"experiment_logs_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    logger = TeeLogger(log_dir=log_dir, prefix="experiment_output")
    sys.stdout = logger
   
    try:
        # Set random seeds for reproducibility
        np.random.seed(42)
        torch.manual_seed(42)
        random.seed(42)
       
        # Example 1: Star graph
        print("\n\n" + "#"*80)
        print("# EXPERIMENT 1: STAR GRAPH")
        print("#"*80)
        game_star, _, _ = run_experiment(
            num_nodes=301,
            graph_type='star',
            save_dir=logger.log_dir
        )
       
        # Example 2: Small-world graph
        print("\n\n" + "#"*80)
        print("# EXPERIMENT 2: SMALL-WORLD GRAPH")
        print("#"*80)
        game_sw, _, _ = run_experiment(
            num_nodes=301,
            graph_type='small_world',
            k=6,
            p=0.3,
            save_dir=logger.log_dir
        )
       
        # Example 3: Regular graph
        print("\n\n" + "#"*80)
        print("# EXPERIMENT 3: REGULAR GRAPH")
        print("#"*80)
        game_reg, _, _ = run_experiment(
            num_nodes=301,
            graph_type='regular',
            degree=6,
            save_dir=logger.log_dir
        )
       
        # Example 4: Bipartite graph
        print("\n\n" + "#"*80)
        print("# EXPERIMENT 4: BIPARTITE GRAPH")
        print("#"*80)
        game_bip, _, _ = run_experiment(
            num_nodes=301,
            graph_type='bipartite',
            p=0.4,
            save_dir=logger.log_dir
        )
       
        # Example 5: Erdos-Renyi graph
        print("\n\n" + "#"*80)
        print("# EXPERIMENT 5: ERDOS-RENYI GRAPH")
        print("#"*80)
        game_er, _, _ = run_experiment(
            num_nodes=301,
            graph_type='erdos_renyi',
            p=0.02,
            save_dir=logger.log_dir
        )
       
        print("\n\n" + "#"*80)
        print("# ALL EXPERIMENTS COMPLETED!")
        print("#"*80)
       
    except Exception as e:
        print(f"\n{'='*80}")
        print("ERROR OCCURRED")
        print(f"{'='*80}")
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
   
    finally:
        # Close logger
        logger.close()